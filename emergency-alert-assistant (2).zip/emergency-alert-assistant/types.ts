export interface EmergencyContact {
  id: string;
  name: string;
  relation: string;
  phone: string;
}
