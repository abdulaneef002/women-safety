const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const twilio = require('twilio');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Multer setup for video/audio upload
const upload = multer({ dest: 'uploads/' });

// Twilio setup (replace with your credentials)
const accountSid = 'AC12a2ea733301a74dd372e3385baf83af';
const authToken = 'd747f1b5da0a8895d6ce8c96cb337760';
const twilioPhone = '+17638786072';
const client = twilio(accountSid, authToken);

app.get('/', (req, res) => {
  res.send('Backend server is running!');
});

// Example API route
app.get('/api/hello', (req, res) => {
  res.json({ message: 'Hello from backend!' });
});

// Updated /api/send-alert route
app.post('/api/send-alert', upload.single('video'), async (req, res) => {
  try {
    const { latitude, longitude, message, recipients } = req.body;
    const recipientsList = JSON.parse(recipients);
    const videoPath = req.file ? path.resolve(req.file.path) : null;

    // Send SMS to each contact
    let results = [];
    for (const phone of recipientsList) {
      try {
        const sms = await client.messages.create({
          body: `EMERGENCY ALERT!\nLocation: https://maps.google.com/?q=${latitude},${longitude}\nMessage: ${message}`,
          from: twilioPhone,
          to: phone
        });
        results.push({ phone, status: 'sent', sid: sms.sid });
      } catch (err) {
        results.push({ phone, status: 'failed', error: err.message });
      }
    }

    // Optionally, save video/audio file for later use
    // You can add code to email or WhatsApp the file if needed

    res.json({ status: 'success', message: 'Alert sent to contacts!', results });
  } catch (err) {
    res.status(500).json({ status: 'error', message: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
